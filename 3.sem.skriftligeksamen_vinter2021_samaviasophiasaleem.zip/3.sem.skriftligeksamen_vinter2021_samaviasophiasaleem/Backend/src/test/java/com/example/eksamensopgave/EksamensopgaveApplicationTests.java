package com.example.eksamensopgave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EksamensopgaveApplicationTests {

    @Test
    void contextLoads() {
    }

}
