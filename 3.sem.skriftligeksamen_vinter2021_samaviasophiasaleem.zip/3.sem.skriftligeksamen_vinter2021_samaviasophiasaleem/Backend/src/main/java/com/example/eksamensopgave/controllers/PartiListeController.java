package com.example.eksamensopgave.controllers;
import com.example.eksamensopgave.models.PartiListe;
import com.example.eksamensopgave.repositories.PartiListeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin("*")
@RestController
public class PartiListeController {

    @Autowired
    PartiListeRepository partiListeRepository;

    /**
     * @return a list of movies when the /movies is called
     */

    @GetMapping("/partiListe")
    public List<PartiListe> getAllPartiListe() {
        return partiListeRepository.findAll();
    }



}
