package com.example.eksamensopgave.models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Entity
public class PartiListe {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //autoincrement
    private int parti_ID;
    private String partiNavn;
    private String partiBogstav;
    private String stemmetal;


    @OneToMany
    @JoinColumn(name = "parti_ID")
    @JsonBackReference

    private Set<Kandidat> kandidatliste = new HashSet<>();



}
