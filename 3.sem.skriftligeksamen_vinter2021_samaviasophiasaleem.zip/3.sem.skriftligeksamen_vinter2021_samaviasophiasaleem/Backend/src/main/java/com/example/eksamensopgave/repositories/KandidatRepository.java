package com.example.eksamensopgave.repositories;
import com.example.eksamensopgave.models.Kandidat;
import org.springframework.data.jpa.repository.JpaRepository;


public interface KandidatRepository extends JpaRepository<Kandidat, Integer> {

}





