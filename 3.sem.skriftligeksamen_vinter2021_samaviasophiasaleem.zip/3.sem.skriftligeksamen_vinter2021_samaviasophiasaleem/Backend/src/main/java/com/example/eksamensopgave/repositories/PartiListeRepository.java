package com.example.eksamensopgave.repositories;

import com.example.eksamensopgave.models.PartiListe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PartiListeRepository extends JpaRepository<PartiListe, Integer> {

}
