package com.example.eksamensopgave.controllers;
import com.example.eksamensopgave.models.Kandidat;
import com.example.eksamensopgave.repositories.KandidatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@CrossOrigin("*")
@RestController
public class KandidatController {
    @Autowired
    KandidatRepository kandidatRepository;

    @GetMapping("/kandidatliste")
    public List<Kandidat> getAllKandidat() {
        return kandidatRepository.findAll();
    }

    @PutMapping(value = "/opdaterKandidat", consumes = "application/json")
    public ResponseEntity<Kandidat> opdaterKandidat(@RequestBody Kandidat kandidat) {
        kandidatRepository.save(kandidat);
        return new ResponseEntity<Kandidat>(kandidat, HttpStatus.OK);
    }


    @PostMapping(value = "/opretKandidat", consumes = "application/json")
    public ResponseEntity<Kandidat> opretKandidat(@RequestBody Kandidat kandidat) {
        kandidatRepository.save(kandidat);
        return new ResponseEntity<Kandidat>(kandidat, HttpStatus.CREATED);
    }

    @DeleteMapping("/kandidatDelete/{kandidat_ID}")
    public ResponseEntity<Object> deleteKandidat(@PathVariable int kandidat_ID) {
        try {
            kandidatRepository.deleteById(kandidat_ID);
        }catch (Exception err) {
            return new ResponseEntity<>("Kandidat with ID: " + kandidat_ID + " not found", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }


}


