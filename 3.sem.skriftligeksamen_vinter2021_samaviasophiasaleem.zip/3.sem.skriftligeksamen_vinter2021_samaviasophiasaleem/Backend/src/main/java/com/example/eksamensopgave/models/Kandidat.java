package com.example.eksamensopgave.models;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@NoArgsConstructor @AllArgsConstructor @Getter @Setter
@Entity
public class Kandidat {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //autoincrement
    private Integer kandidat_ID;
    private String kandidatNavn;
    private String partiBogstav;
    private String personligeStemmetal;


    @ManyToOne
    @JoinColumn(name = "parti_ID")
    private PartiListe partiListe;
}
