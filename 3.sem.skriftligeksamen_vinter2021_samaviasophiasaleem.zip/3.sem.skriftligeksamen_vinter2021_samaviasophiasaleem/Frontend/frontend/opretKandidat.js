const partiSelector = document.getElementById("partiListeDropDown");
let selectedParti;

async function loadAsyncData(){
    await fetchPartiListeFromDB(); //async gør det i bestemt rækkefølge await venter til forrige metode er færdigkørt
    createDropDown();
}

function createDropDown(){
    partiListeMap.forEach(partiListe => {
        const options = document.createElement("option");
        options.textContent = partiListe.partiNavn;
        options.value = partiListe.parti_ID;
        console.log(options)
        partiSelector.appendChild(options);
    })

    partiSelector.addEventListener("change",(event) => {
        const optionIndex = partiSelector.value;

        partiListeMap.forEach(partiListe => {
            if (parseInt(optionIndex) === parseInt(partiListe.parti_ID)) {
                selectedParti = partiListe;
            }
        })
    })
}
loadAsyncData();

document.addEventListener("DOMContentLoaded",createFormEventListener);

function createFormEventListener() { //Laver eventet der lytter til hvornår vi henter formen
    const formObject = document.getElementById("assign");
    console.log(formObject)
    formObject.addEventListener("submit",handleKandidatSubmit);
}

async function handleKandidatSubmit(event) {
    event.preventDefault();

    const form = event.currentTarget; //Fortæller hvilket event (submittet) som vi skal tage fra
    const url = form.action; //Tager det url som står i action i formheaderen

    try {
        const formData = new FormData(form);
        console.log(form)
        await insertKandidatInBackend(url,formData);
    } catch(error) {
        alert(error.message);
    }

    window.location.href = "/Frontend/frontend/visKandidat.html"
}

async function insertKandidatInBackend(url, formData) {
    const plainFormData = Object.fromEntries(formData.entries());

    const partiJSON = {
        kandidatNavn : plainFormData.kandidatNavn,
        partiBogstav : plainFormData.partiBogstav,
        stemmetal : plainFormData.stemmetal,



        parti : {
            parti_ID : selectedParti.parti_ID
        }
    }


    const JSONObjectToJSONString = JSON.stringify(partiJSON);
    console.log(partiJSON)

    const POSTOptions = {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSONObjectToJSONString
    }

    const response = await fetch(url, POSTOptions);

    return response.json();
}
