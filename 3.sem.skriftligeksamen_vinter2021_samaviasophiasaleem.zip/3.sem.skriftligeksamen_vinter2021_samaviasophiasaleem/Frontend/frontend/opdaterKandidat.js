
gemOpdater()

function gemOpdater () {
    document.getElementById("saveBtn").onclick = opdaterKandidat

}


function opdaterKandidat () {

    const kandidatNavn = document.getElementById("nameInput").value
    document.getElementById("bogstavInput").value
    document.getElementById("nameInput").value

    const options = {
        method: "PUT",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },

        body: JSON.stringify({
            kandidat_ID: kandidat_ID,
            kandidatNavn: kandidatNavn,
            partiBogstav: partiBogstav,
            personligeStemmetal: personligeStemmetal
        })
    }

    fetch("http://localhost:8080/opdaterKandidat", options)

}