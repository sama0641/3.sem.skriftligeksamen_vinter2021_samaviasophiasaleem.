//URL til controlleren i backenden som henter alle rooms i og bliver omdannet dem til JSON format
const fetchPartiListe = "http://localhost:8080/partiListe"

//Query for knappen som aktivere vores request til databasen
const partiListeMap = new Map();

//fetching employee from database
async function fetchPartiListeFromDB() {
    const promise = fetch(fetchPartiListe).then(response => response.json())
    await promise.then(data =>{ //Reagerer på dataen der kommer fra vores RESTapi
        data.forEach(partiListe => { //Vi hiver hvert parti ud af promiseobjektet
            partiListeMap.set(partiListe.parti_ID, partiListe);
        })
    })
    console.log(partiListeMap);
}
fetchPartiListeFromDB()