const fetchKandidatListe = "http://localhost:8080/kandidatliste"


//Query for knappen som aktiverer request til databasen
const kandidatMap = new Map();

//fetching from database
async function fetchKandidatListeFromDB() {
    const promise = fetch(fetchKandidatListe).then(response => response.json())
    await promise.then(data =>{ //reagerer på dataen der kommer fra vores RESTapi
        data.forEach(kandidat => { //hiver hver entity ud af promiseobjektet
            kandidatMap.set(kandidat.kandidat_ID, kandidat);
        })
    })
    console.log(kandidatMap);
}





/* opsætKnap()

function opsætKnap () {
    document.getElementById("opsætKnap").onclick = visOpdaterKandidat

}

function visOpdaterKandidat() {
    sessionStorage.setItem("", "partyId")
}

 */