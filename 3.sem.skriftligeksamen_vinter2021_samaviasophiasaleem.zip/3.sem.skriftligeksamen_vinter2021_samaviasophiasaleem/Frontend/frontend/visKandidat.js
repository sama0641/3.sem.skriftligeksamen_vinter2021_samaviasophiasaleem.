//URL til controlleren i backenden som henter alle rooms i og bliver omdannet dem til JSON format
const out = (str) => console.log(str);

fetchKandidatListeFromDB();

const table = document.getElementById("kandidat_table");

function addRow(kandidat){
    let rowCount = table.rows.length;
    let row = table.insertRow(rowCount);
    row.id = kandidat.kandidat;

    let cell1 = row.insertCell(0);
    cell1.innerHTML = kandidat.kandidatNavn;

    let cell2 = row.insertCell(1);
    cell2.innerHTML = kandidat.partiBogstav;

    let cell3 = row.insertCell(2);
    cell3.innerHTML = kandidat.personligeStemmetal;

    let cell4 = row.insertCell(3);
    let pbDelete = document.createElement("input");
    pbDelete.type = "button";
    pbDelete.setAttribute("value", "slet denne kandidat");
    pbDelete.onclick = function () {
        document.getElementById(kandidat.kandidat).remove();
        deleteKandidat(kandidat)
    }
    cell4.appendChild(pbDelete); //appendvhild dvs næste i rækken skal udføre opgaven

}


async function createTableFromMap() {
    await fetchKandidatListeFromDB()
    console.log("Creating table from map")
    for (const kandidatKey of kandidatMap.keys()) {
        const kandidat1 = kandidatMap.get(kandidatKey);
        addRow(kandidat1);
    }
}

createTableFromMap()