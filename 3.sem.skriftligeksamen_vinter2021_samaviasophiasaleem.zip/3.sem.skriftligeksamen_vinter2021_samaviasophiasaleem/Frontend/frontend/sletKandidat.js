async function deleteKandidat(kandidat) {
    try {
        const response = await restDeleteKandidat(kandidat);
    } catch (error) {
        alert(error.message)
        out(error)
    }
}

async function restDeleteKandidat(kandidat) {
    const url = "http://localhost:8080/kandidatDelete/" + kandidat.kandidat_ID;

    const fetchOptions = {
        method : "DELETE",
        headers : {
            "Control-Type" : "application/json"
        },
        body : ""
    }
    const response = await fetch(url, fetchOptions)
    if (!response.ok) {
        out("Der skete en fejl")
    }

    window.location.href = "/Frontend/frontend/visKandidat.html"
    return response;
}


