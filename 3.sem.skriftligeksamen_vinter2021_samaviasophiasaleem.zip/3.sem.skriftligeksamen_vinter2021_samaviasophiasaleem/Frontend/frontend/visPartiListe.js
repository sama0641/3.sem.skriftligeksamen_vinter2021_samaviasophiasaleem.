const out = (str) => console.log(str);

const table = document.getElementById("partiListe_table");

function addRow(partiListe){
    let rowCount = table.rows.length;
    let row = table.insertRow(rowCount);
    row.id = partiListe.partiListe;

    let cell1 = row.insertCell(0);
    cell1.innerHTML = partiListe.partiBogstav;

    let cell2 = row.insertCell(1);
    cell2.innerHTML = partiListe.partiNavn;

    let cell3 = row.insertCell(2);
    cell3.innerHTML = partiListe.stemmetal;

}

async function createTableFromMap() {
    await fetchPartiListeFromDB()
    console.log("Creating table from map")
    for (const partiKey of partiListeMap.keys()) {
        const parti1 = partiListeMap.get(partiKey);
        addRow(parti1);
    }
}

createTableFromMap()


